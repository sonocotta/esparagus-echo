G04 Layer: TopSolderMaskLayer*
G04 EasyEDA v6.5.61, 2026-11-17 21:18:13*
G04 c07f886f57a64c37b433a6d896e29c67,9c416354eb984020824aaf9c885bead6,10*
G04 Gerber Generator version 0.2*
G04 Scale: 100 percent, Rotated: No, Reflected: No *
G04 Dimensions in millimeters *
G04 leading zeros omitted , absolute positions ,4 integer and 5 decimal *
%FSLAX45Y45*%
%MOMM*%

%ADD10O,10.10158X4.101592*%
%ADD11C,6.8016*%
%ADD12C,0.0113*%

%LPD*%
D10*
G01*
X-99999Y-370001D03*
D11*
G01*
X-99999Y510006D03*
M02*
